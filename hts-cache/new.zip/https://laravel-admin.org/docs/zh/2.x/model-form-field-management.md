<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Laravel admin | 组件管理</title>


    <link rel="stylesheet" href="/css/google-fonts.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/prism/prism.css">
    <link rel="stylesheet" href="/vendor/docs/css/adminlte.min.css">
    <link rel="stylesheet" href="/vendor/docs/css/docs.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.css" />
    <script src="/vendor/docs/plugins/jquery/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed text-sm">
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
            </li>

                        <li class="nav-item dropdown">
                <a class="nav-link bg-info rounded dropdown-toggle" href="#" id="navbarVersionDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    2.0-BETA
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarVersionDropdown">
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/1.x">1.x</a>
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/2.x">2.0-BETA</a>
                                    </div>
            </li>
                    </ul>

        <!-- SEARCH FORM -->
        <form class="form-check-inline ml-3">
            <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar docsearch" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <span class="ml-5"><a href="/docs/zh/1.x/changelog#v1.8.9%20(2020-11-02)" class="text-danger">目前于1.8版本发现一处未授权访问安全漏洞，正在使用1.8版本的同学请尽快更新到v1.8.10版本！！！</a></span>

        <ul class="navbar-nav ml-auto">
            <li class="nav-item d-none d-sm-inline-block">
              <a href="/" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://demo.laravel-admin.org" target="_blank" class="nav-link">Demo</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://github.com/z-song/laravel-admin" class="nav-link" target="_blank"><i class="fab fa-github"></i></a>
            </li>

            <li class="nav-item dropdown ml-2">
                <a class="btn btn-info btn-sm" href="#" id="navbarLangDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-globe-asia"></i>
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarLangDropdown">
                                        <a class="dropdown-item" href="/docs/zh">中文</a>
                                        <a class="dropdown-item" href="/docs/en">English</a>
                                    </div>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar elevation-4 sidebar-light-info">
        <a href="/" class="brand-link logo-switch navbar-light text-info">
            <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs" style="height: 29px;margin-top: 1px;margin-left: 13px;">
            <span>
                <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 30px">
                <span style="position: absolute;left:58px;" class="text-lg">aravel-admin</span>
            </span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <p></p><div class="bg-secondary m-3 p-2 rounded">
    <a href="https://laravel-admin.org/extensions/100" target="_blank">
        多租户插件
        <span class="badge badge-info ml-3">立即查看 &gt;</span>
    </a>
</div><ul role="menu" class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview">
<li class="nav-item"><a href="/docs/zh/2.x/README" class="nav-link"><i class="nav-icon fas fa-home"></i><p>Overview</p></a></li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>入门
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/2.x/installation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>安装</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/quick-start" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快速开始</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/configuration" class="nav-link"><i class="nav-icon far fa-circle"></i><p>配置文件</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/upgrading" class="nav-link"><i class="nav-icon far fa-circle"></i><p>版本升级</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/content-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>页面内容和布局</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-th"></i><p>模型表格
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/2.x/model-table" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-column" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-column-display" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-filters" class="nav-link"><i class="nav-icon far fa-circle"></i><p>查询过滤</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-column-filter" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列过滤器</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-inline-edit" class="nav-link"><i class="nav-icon far fa-circle"></i><p>行内编辑</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-custom-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义行&amp;批量操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-export" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据导出</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-header-footer" class="nav-link"><i class="nav-icon far fa-circle"></i><p>头部和脚部</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-total-row" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格统计行</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-quick-search" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷搜索</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-spec-selector" class="nav-link"><i class="nav-icon far fa-circle"></i><p>规格选择器</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-quick-create" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷创建</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-data" class="nav-link"><i class="nav-icon far fa-circle"></i><p>外部数据源</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-hotkeys" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷键</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-table-soft-deletes" class="nav-link"><i class="nav-icon far fa-circle"></i><p>软删除</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-paste"></i><p>模型表单
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/2.x/model-form" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基础组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-upload" class="nav-link"><i class="nav-icon far fa-circle"></i><p>图片/文件上传</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-json-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>JSON组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-relationships" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关系处理</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-linkage" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单联动</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-field-management" class="nav-link"><i class="nav-icon far fa-circle"></i><p>组件管理</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-validation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单验证</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-callback" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单回调</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-form-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单布局</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-eye"></i><p>模型详情
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/2.x/model-show" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-show-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>字段显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-show-relationship" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关联关系</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/model-show-extension" class="nav-link"><i class="nav-icon far fa-circle"></i><p>显示扩展</p></a></li>
</ul>
</li>
<li class="nav-item"><a href="/docs/zh/2.x/model-tree" class="nav-link"><i class="nav-icon fas fa-tree"></i><p>数据模型树</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/data-form" class="nav-link"><i class="nav-icon fas fa-database"></i><p>数据表单</p></a></li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fab fa-js"></i><p>前端
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/2.x/frontend-assets" class="nav-link"><i class="nav-icon far fa-circle"></i><p>前端资源</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/view-rendering" class="nav-link"><i class="nav-icon far fa-circle"></i><p>视图渲染</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/vuejs-usage" class="nav-link"><i class="nav-icon fab fa-vuejs"></i><p>Vuejs使用</p></a></li>
</ul>
</li>
<li class="nav-item"><a href="/docs/zh/2.x/localization" class="nav-link"><i class="nav-icon fas fa-language"></i><p>语言本地化</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/extension-development" class="nav-link"><i class="nav-icon fas fa-anchor"></i><p>扩展开发</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/commands" class="nav-link"><i class="nav-icon fas fa-terminal"></i><p>控制台命令</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/content-message" class="nav-link"><i class="nav-icon fas fa-comments"></i><p>页面消息</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/widgets" class="nav-link"><i class="nav-icon fas fa-box"></i><p>前端组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/custom-navbar" class="nav-link"><i class="nav-icon fas fa-compass"></i><p>自定义头部导航</p></a></li>
<li class="nav-item"><a href="/docs/zh/2.x/qa" class="nav-link"><i class="nav-icon fas fa-question-circle"></i><p>常见问题</p></a></li>
</ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper pl-5 pr-4 py-2" id="pjax-container">
        <div class="content-header">
            <h1 class="text-dark">组件管理</h1>
        </div>

        <div class="content px-2">

            <div class="row">
                <div class="col">
                    <div class="toc m-4">
                        <ul>
                                                        <li>
                                <a href="#移除已有组件">移除已有组件</a>
                                                            </li>
                                                        <li>
                                <a href="#自定义组件">自定义组件</a>
                                                                <ul>
                                                                        <li>
                                        <a href="#集成wangEditor">集成wangEditor</a>
                                    </li>
                                                                        <li>
                                        <a href="#集成ckeditor">集成ckeditor</a>
                                    </li>
                                                                        <li>
                                        <a href="#集成PHP editor">集成PHP editor</a>
                                    </li>
                                                                    </ul>
                                                            </li>
                                                    </ul>
                    </div>
                </div>
                <div class="col">
                    <div id="ad" class="float-right">
                        <script async src="https://cdn.carbonads.com/carbon.js?serve=CK7DT53L&placement=laraveladminorg" id="_carbonads_js"></script>
                    </div>
                </div>
            </div>

            
<h2 id="移除已有组件"><a href="#%E7%A7%BB%E9%99%A4%E5%B7%B2%E6%9C%89%E7%BB%84%E4%BB%B6">移除已有组件</a></h2>
<p>form表单内置的<code>map</code>和<code>editor</code>组件通过cdn的方式引用了前端文件，如果网络方面有问题，可以通过下面的方式将它们移除</p>
<p>找到文件<code>app/Admin/bootstrap.php</code>,如果文件不存在，请更新<code>laravel-admin</code>，然后新建该文件</p>
<pre><code class="language-php">
&lt;?php

use Encore\Admin\Form;

Form::forget('map');
Form::forget('editor');

// or

Form::forget(['map', 'editor']);
</code></pre>
<p>这样就去掉了这两个组件，可以通过该方式去掉其它组件。</p>
<h2 id="自定义组件"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E7%BB%84%E4%BB%B6">自定义组件</a></h2>
<p>用下面的两个例子来说明如何扩展组件</p>
<h3 id="集成wangEditor"><a href="#%E9%9B%86%E6%88%90wangEditor">集成wangEditor</a></h3>
<p><a href="http://www.wangeditor.com/">wangEditor</a>是一个优秀的国产的轻量级富文本编辑器， 通过下面的步骤集成到form表单中：</p>
<p>然后新建组件类<code>app/Admin/Extensions/WangEditor.php</code>。</p>
<pre><code class="language-php">
&lt;?php

namespace App\Admin\Extensions;

use Encore\Admin\Form\Field;

class WangEditor extends Field
{
    protected $view = 'admin.wang-editor';
}</code></pre>
<p>新建视图文件<code>resources/views/admin/wang-editor.blade.php</code>：</p>
<pre><code class="language-php">&lt;div {!! admin_attrs($group_attrs) !!}&gt;
    &lt;label for="{{ $id }}" class="{{ $viewClass['label'] }} control-label"&gt;{{ $label }}&lt;/label&gt;
    &lt;div class="{{ $viewClass['field'] }}"&gt;
        &lt;div class="{{ $class }}"&gt;
            &lt;p&gt;{!! $value !!}&lt;/p&gt;
        &lt;/div&gt;
        &lt;textarea name="{{ $name }}" class="d-none" rows="{{ $rows }}" placeholder="{{ $placeholder }}"&gt;{!! $value !!}&lt;/textarea&gt;
        @include('admin::form.error')
        @include('admin::form.help-block')
    &lt;/div&gt;
&lt;/div&gt;

&lt;script src="https://cdn.jsdelivr.net/npm/wangeditor@3.1.1/release/wangEditor.min.js"&gt;&lt;/script&gt;

&lt;script @script&gt;
    var E = window.wangEditor;
    var $editor = new E(this);
    var $textarea = $(this).parent().find('textarea');
    $editor.customConfig.onchange = function (html) {
        $textarea.val(html);
    }
    $editor.customConfig.zIndex = 100;
    $editor.create();
&lt;/script&gt;
</code></pre>
<p>然后注在<code>app/Admin/bootstrap.php</code>中添加以下代码进行注册：</p>
<pre><code class="language-php">
&lt;?php

use App\Admin\Extensions\WangEditor;
use Encore\Admin\Form;

Form::extend('editor', WangEditor::class);</code></pre>
<p>在表单中使用:</p>
<pre><code class="language-php">$form-&gt;editor('content');</code></pre>
<h3 id="集成ckeditor"><a href="#%E9%9B%86%E6%88%90ckeditor">集成ckeditor</a></h3>
<p>然后新建扩展文件<code>app/Admin/Extensions/Form/CKEditor.php</code>:</p>
<pre><code class="language-php">&lt;?php

namespace App\Admin\Extensions;

use Encore\Admin\Form\Field\Textarea;

class CKEditor extends Textarea
{
    protected $view = 'admin.ckeditor';
}</code></pre>
<p>新建view <code>resources/views/admin/ckeditor.blade.php</code>:</p>
<pre><code class="language-html">&lt;div {!! admin_attrs($group_attrs) !!}&gt;
    &lt;label for="{{$id}}" class="{{$viewClass['label']}} control-label"&gt;{{$label}}&lt;/label&gt;
    &lt;div class="{{$viewClass['field']}}"&gt;
        &lt;textarea name="{{$name}}" class="form-control {{$class}}" rows="{{ $rows }}" placeholder="{{ $placeholder }}" {!! $attributes !!} &gt;{!! $value !!}&lt;/textarea&gt;
        @include('admin::form.error')
        @include('admin::form.help-block')
    &lt;/div&gt;
&lt;/div&gt;

&lt;script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"&gt;&lt;/script&gt;

&lt;script @script&gt;
    CKEDITOR.replace('{{ $name }}');
&lt;/script&gt;</code></pre>
<p>然后在<code>app/Admin/bootstrap.php</code>中注册扩展：</p>
<pre><code class="language-php">use App\Admin\Extensions\Form\CKEditor;
use Encore\Admin\Form;

Form::extend('ckeditor', CKEditor::class);</code></pre>
<p>然后就能在form中使用了:</p>
<pre><code class="language-php">$form-&gt;ckeditor('content');</code></pre>
<h3 id="集成PHP editor"><a href="#%E9%9B%86%E6%88%90PHP%20editor">集成PHP editor</a></h3>
<p>通过下面的步骤来扩展一个基于<a href="http://codemirror.net/index.html">codemirror</a>的PHP代码编辑器，效果参考<a href="http://codemirror.net/mode/php/">PHP mode</a>。</p>
<p>新建组件类<code>app/Admin/Extensions/PHPEditor.php</code>:</p>
<pre><code class="language-php">&lt;?php

namespace App\Admin\Extensions;

use Encore\Admin\Form\Field\Textarea;

class PHPEditor extends Textarea
{
    protected $view = 'admin.php-editor';
}</code></pre>
<p>创建视图<code>resources/views/admin/php-editor.blade.php</code>:</p>
<pre><code class="language-html">&lt;div {!! admin_attrs($group_attrs) !!}&gt;
    &lt;label for="{{ $id }}" class="{{ $viewClass['label'] }} control-label"&gt;{{ $label }}&lt;/label&gt;
    &lt;div class="{{ $viewClass['field'] }}"&gt;
        &lt;textarea name="{{ $name }}" class="{{ $class }}" rows="{{ $rows }}" placeholder="{{ $placeholder }}" {!! $attributes !!} &gt;{{ $value }}&lt;/textarea&gt;
        @include('admin::form.error')
        @include('admin::form.help-block')
    &lt;/div&gt;
&lt;/div&gt;

&lt;link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/lib/codemirror.css"&gt;

&lt;script dep src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/lib/codemirror.min.js"&gt;&lt;/script&gt;

&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/addon/edit/matchbrackets.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/htmlmixed/htmlmixed.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/xml/xml.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/javascript/javascript.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/css/css.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/clike/clike.js"&gt;&lt;/script&gt;
&lt;script src="https://cdn.jsdelivr.net/npm/codemirror@5.57.0/mode/php/php.js"&gt;&lt;/script&gt;

&lt;script @script&gt;
    var textarea = this;
    setTimeout(function () {
        var editor = CodeMirror.fromTextArea(textarea, {
            lineNumbers: true,
            matchBrackets: true,
            mode: "application/x-httpd-php",
            indentUnit: 4,
            indentWithTabs: true
        });
    }, 10)
&lt;/script&gt;

&lt;style&gt;
    .CodeMirror {
        border: 1px solid #cccccc;
    }
&lt;/style&gt;</code></pre>
<p>然后在<code>app/Admin/bootstrap.php</code>中注册扩展：</p>
<pre><code class="language-php">&lt;?php

use App\Admin\Extensions\PHPEditor;
use Encore\Admin\Form;

Form::extend('php', PHPEditor::class);
</code></pre>
<p>然后就能在form中使用了:</p>
<pre><code class="language-php">$form-&gt;php('code');</code></pre>
<p>通过这种方式，可以添加任意你想要添加的form组件。</p>
        </div>
    </div>
    <footer class="main-footer">
        <div class="float-right d-none d-sm-inline">
            v1.8
        </div>
        <strong>Documentation powered by <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    </footer>
</div>

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-52301626-3', 'auto');
    ga('send', 'pageview');

</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.js"></script>
<script type="text/javascript"> docsearch({
        apiKey: 'f67cec1a592c4a25a3e1d1c0dc38b6af',
        indexName: 'laravel-admin',
        inputSelector: '.docsearch',
        debug: false // Set debug to true if you want to inspect the dropdown
    });
</script>

<script src="/vendor/docs/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/vendor/docs/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="/vendor/docs/js/adminlte.min.js"></script>
<script src="/vendor/docs/plugins/jquery-pjax/jquery.pjax.js"></script>
<script src="/vendor/docs/plugins/prism/prism.js" data-manual></script>
<script src="/vendor/docs/js/docs.js?id=3" data-manual></script>
</body>
</html>
