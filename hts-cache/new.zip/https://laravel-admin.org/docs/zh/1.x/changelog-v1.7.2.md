<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Laravel admin | v1.7.2 (2019-06-23)</title>


    <link rel="stylesheet" href="/css/google-fonts.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/prism/prism.css">
    <link rel="stylesheet" href="/vendor/docs/css/adminlte.min.css">
    <link rel="stylesheet" href="/vendor/docs/css/docs.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.css" />
    <script src="/vendor/docs/plugins/jquery/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed text-sm">
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
            </li>

                        <li class="nav-item dropdown">
                <a class="nav-link bg-info rounded dropdown-toggle" href="#" id="navbarVersionDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    1.x
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarVersionDropdown">
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/1.x">1.x</a>
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/2.x">2.0-BETA</a>
                                    </div>
            </li>
                    </ul>

        <!-- SEARCH FORM -->
        <form class="form-check-inline ml-3">
            <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar docsearch" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <span class="ml-5"><a href="/docs/zh/1.x/changelog#v1.8.9%20(2020-11-02)" class="text-danger">目前于1.8版本发现一处未授权访问安全漏洞，正在使用1.8版本的同学请尽快更新到v1.8.10版本！！！</a></span>

        <ul class="navbar-nav ml-auto">
            <li class="nav-item d-none d-sm-inline-block">
              <a href="/" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://demo.laravel-admin.org" target="_blank" class="nav-link">Demo</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://github.com/z-song/laravel-admin" class="nav-link" target="_blank"><i class="fab fa-github"></i></a>
            </li>

            <li class="nav-item dropdown ml-2">
                <a class="btn btn-info btn-sm" href="#" id="navbarLangDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-globe-asia"></i>
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarLangDropdown">
                                        <a class="dropdown-item" href="/docs/zh">中文</a>
                                        <a class="dropdown-item" href="/docs/en">English</a>
                                    </div>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar elevation-4 sidebar-light-info">
        <a href="/" class="brand-link logo-switch navbar-light text-info">
            <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs" style="height: 29px;margin-top: 1px;margin-left: 13px;">
            <span>
                <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 30px">
                <span style="position: absolute;left:58px;" class="text-lg">aravel-admin</span>
            </span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <p></p><p></p><ul role="menu" class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview">
<li class="nav-item"><a href="/docs/zh/1.x/README" class="nav-link"><i class="nav-icon fas fa-home"></i><p>Overview</p></a></li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>入门
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/installation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>安装</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/quick-start" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快速开始</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/configuration" class="nav-link"><i class="nav-icon far fa-circle"></i><p>配置文件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/upgrading" class="nav-link"><i class="nav-icon far fa-circle"></i><p>版本升级</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>页面内容和布局</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/questions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>统一回复</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-th"></i><p>模型表格
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-grid" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-display" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-filters" class="nav-link"><i class="nav-icon far fa-circle"></i><p>查询过滤</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-filter" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列过滤器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-inline-edit" class="nav-link"><i class="nav-icon far fa-circle"></i><p>行内编辑</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义行&amp;批量操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-export" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据导出</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-header-footer" class="nav-link"><i class="nav-icon far fa-circle"></i><p>头部和脚部</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-total-row" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格统计行</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-search" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷搜索</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-spec-selector" class="nav-link"><i class="nav-icon far fa-circle"></i><p>规格选择器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-create" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷创建</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-tools" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义工具</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-data" class="nav-link"><i class="nav-icon far fa-circle"></i><p>外部数据源</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-hotkeys" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷键</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-soft-deletes" class="nav-link"><i class="nav-icon far fa-circle"></i><p>软删除</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-paste"></i><p>模型表单
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-form" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基础组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-upload" class="nav-link"><i class="nav-icon far fa-circle"></i><p>图片/文件上传</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-json-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>JSON组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-relationships" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关系处理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-linkage" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单联动</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-field-management" class="nav-link"><i class="nav-icon far fa-circle"></i><p>组件管理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-validation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单验证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-callback" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单回调</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单布局</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-eye"></i><p>模型详情
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-show" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>字段显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-relationship" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关联关系</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-extension" class="nav-link"><i class="nav-icon far fa-circle"></i><p>显示扩展</p></a></li>
</ul>
</li>
<li class="nav-item"><a href="/docs/zh/1.x/model-tree" class="nav-link"><i class="nav-icon fas fa-tree"></i><p>数据模型树</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/data-form" class="nav-link"><i class="nav-icon fas fa-database"></i><p>数据表单</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/localization" class="nav-link"><i class="nav-icon fas fa-language"></i><p>语言本地化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/frontend" class="nav-link"><i class="nav-icon fab fa-js"></i><p>CSS/JavaScript</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/extension-development" class="nav-link"><i class="nav-icon fas fa-anchor"></i><p>扩展开发</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/commands" class="nav-link"><i class="nav-icon fas fa-terminal"></i><p>控制台命令</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-message" class="nav-link"><i class="nav-icon fas fa-comments"></i><p>页面消息</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/widgets" class="nav-link"><i class="nav-icon fas fa-box"></i><p>前端组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/permission" class="nav-link"><i class="nav-icon fas fa-ban"></i><p>用户、角色、权限</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-authentication" class="nav-link"><i class="nav-icon fas fa-handshake"></i><p>自定义登录认证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-navbar" class="nav-link"><i class="nav-icon fas fa-compass"></i><p>自定义头部导航</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/qa" class="nav-link"><i class="nav-icon fas fa-question-circle"></i><p>常见问题</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/changelog" class="nav-link"><i class="nav-icon fas fa-history"></i><p>Changelog</p></a></li>
</ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper pl-5 pr-4 py-2" id="pjax-container">
        <div class="content-header">
            <h1 class="text-dark">v1.7.2 (2019-06-23)</h1>
        </div>

        <div class="content px-2">

            <div class="row">
                <div class="col">
                    <div class="toc m-4">
                        <ul>
                                                    </ul>
                    </div>
                </div>
                <div class="col">
                    <div id="ad" class="float-right">
                        <script async src="https://cdn.carbonads.com/carbon.js?serve=CK7DT53L&placement=laraveladminorg" id="_carbonads_js"></script>
                    </div>
                </div>
            </div>

            
<p>在这个版本中，有下面的修改和变更</p>
<p>模型表单</p>
<ul>
<li>修复上传文件组建的文件预览问题</li>
<li>支持form表单上传图片的同时生成缩略图</li>
<li>增加了<code>$form-&gt;file('name')-&gt;downloadable()</code>方法</li>
</ul>
<p>模型表格</p>
<ul>
<li>增加<code>$grid-&gt;column('name')-&gt;downloadable()</code>方法</li>
<li>增加<code>$grid-&gt;column('name')-&gt;color($color)</code>方法</li>
<li>增加<code>$grid-&gt;column('name')-&gt;icon($icons = [])</code>方法</li>
<li>增加<code>$grid-&gt;column('name')-&gt;replace($replacements = [])</code>方法</li>
<li>增加<code>$grid-&gt;column('name')-&gt;filter()</code>方法，实现列过滤，<a href="/docs/zh/1.x/model-grid-column-filter">列过滤文档</a>
</li>
<li>增加<code>$grid-&gt;column('name')-&gt;copyable()</code>方法</li>
<li>增加<code>$grid-&gt;column('name')-&gt;qrcode()</code>方法</li>
<li>优化<code>$grid-&gt;column('name')-&gt;label()</code>和<code>$grid-&gt;column('name')-&gt;badge()</code>方法</li>
<li>实现grid页面的快捷键，<a href="/docs/zh/1.x/model-grid-hotkeys">快捷键文档</a>
</li>
</ul>
        </div>
    </div>
    <footer class="main-footer">
        <div class="float-right d-none d-sm-inline">
            v1.8
        </div>
        <strong>Documentation powered by <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    </footer>
</div>

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-52301626-3', 'auto');
    ga('send', 'pageview');

</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.js"></script>
<script type="text/javascript"> docsearch({
        apiKey: 'f67cec1a592c4a25a3e1d1c0dc38b6af',
        indexName: 'laravel-admin',
        inputSelector: '.docsearch',
        debug: false // Set debug to true if you want to inspect the dropdown
    });
</script>

<script src="/vendor/docs/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/vendor/docs/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="/vendor/docs/js/adminlte.min.js"></script>
<script src="/vendor/docs/plugins/jquery-pjax/jquery.pjax.js"></script>
<script src="/vendor/docs/plugins/prism/prism.js" data-manual></script>
<script src="/vendor/docs/js/docs.js?id=3" data-manual></script>
</body>
</html>
