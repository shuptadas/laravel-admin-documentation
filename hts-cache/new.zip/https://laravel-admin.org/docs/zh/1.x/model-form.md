<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Laravel admin | 基于数据模型的表单</title>


    <link rel="stylesheet" href="/css/google-fonts.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/prism/prism.css">
    <link rel="stylesheet" href="/vendor/docs/css/adminlte.min.css">
    <link rel="stylesheet" href="/vendor/docs/css/docs.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.css" />
    <script src="/vendor/docs/plugins/jquery/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed text-sm">
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
            </li>

                        <li class="nav-item dropdown">
                <a class="nav-link bg-info rounded dropdown-toggle" href="#" id="navbarVersionDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    1.x
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarVersionDropdown">
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/1.x">1.x</a>
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/2.x">2.0-BETA</a>
                                    </div>
            </li>
                    </ul>

        <!-- SEARCH FORM -->
        <form class="form-check-inline ml-3">
            <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar docsearch" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <span class="ml-5"><a href="/docs/zh/1.x/changelog#v1.8.9%20(2020-11-02)" class="text-danger">目前于1.8版本发现一处未授权访问安全漏洞，正在使用1.8版本的同学请尽快更新到v1.8.10版本！！！</a></span>

        <ul class="navbar-nav ml-auto">
            <li class="nav-item d-none d-sm-inline-block">
              <a href="/" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://demo.laravel-admin.org" target="_blank" class="nav-link">Demo</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://github.com/z-song/laravel-admin" class="nav-link" target="_blank"><i class="fab fa-github"></i></a>
            </li>

            <li class="nav-item dropdown ml-2">
                <a class="btn btn-info btn-sm" href="#" id="navbarLangDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-globe-asia"></i>
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarLangDropdown">
                                        <a class="dropdown-item" href="/docs/zh">中文</a>
                                        <a class="dropdown-item" href="/docs/en">English</a>
                                    </div>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar elevation-4 sidebar-light-info">
        <a href="/" class="brand-link logo-switch navbar-light text-info">
            <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs" style="height: 29px;margin-top: 1px;margin-left: 13px;">
            <span>
                <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 30px">
                <span style="position: absolute;left:58px;" class="text-lg">aravel-admin</span>
            </span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <p></p><p></p><ul role="menu" class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview">
<li class="nav-item"><a href="/docs/zh/1.x/README" class="nav-link"><i class="nav-icon fas fa-home"></i><p>Overview</p></a></li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>入门
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/installation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>安装</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/quick-start" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快速开始</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/configuration" class="nav-link"><i class="nav-icon far fa-circle"></i><p>配置文件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/upgrading" class="nav-link"><i class="nav-icon far fa-circle"></i><p>版本升级</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>页面内容和布局</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/questions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>统一回复</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-th"></i><p>模型表格
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-grid" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-display" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-filters" class="nav-link"><i class="nav-icon far fa-circle"></i><p>查询过滤</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-filter" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列过滤器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-inline-edit" class="nav-link"><i class="nav-icon far fa-circle"></i><p>行内编辑</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义行&amp;批量操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-export" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据导出</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-header-footer" class="nav-link"><i class="nav-icon far fa-circle"></i><p>头部和脚部</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-total-row" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格统计行</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-search" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷搜索</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-spec-selector" class="nav-link"><i class="nav-icon far fa-circle"></i><p>规格选择器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-create" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷创建</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-tools" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义工具</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-data" class="nav-link"><i class="nav-icon far fa-circle"></i><p>外部数据源</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-hotkeys" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷键</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-soft-deletes" class="nav-link"><i class="nav-icon far fa-circle"></i><p>软删除</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-paste"></i><p>模型表单
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-form" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基础组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-upload" class="nav-link"><i class="nav-icon far fa-circle"></i><p>图片/文件上传</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-json-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>JSON组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-relationships" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关系处理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-linkage" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单联动</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-field-management" class="nav-link"><i class="nav-icon far fa-circle"></i><p>组件管理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-validation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单验证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-callback" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单回调</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单布局</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-eye"></i><p>模型详情
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-show" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>字段显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-relationship" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关联关系</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-extension" class="nav-link"><i class="nav-icon far fa-circle"></i><p>显示扩展</p></a></li>
</ul>
</li>
<li class="nav-item"><a href="/docs/zh/1.x/model-tree" class="nav-link"><i class="nav-icon fas fa-tree"></i><p>数据模型树</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/data-form" class="nav-link"><i class="nav-icon fas fa-database"></i><p>数据表单</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/localization" class="nav-link"><i class="nav-icon fas fa-language"></i><p>语言本地化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/frontend" class="nav-link"><i class="nav-icon fab fa-js"></i><p>CSS/JavaScript</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/extension-development" class="nav-link"><i class="nav-icon fas fa-anchor"></i><p>扩展开发</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/commands" class="nav-link"><i class="nav-icon fas fa-terminal"></i><p>控制台命令</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-message" class="nav-link"><i class="nav-icon fas fa-comments"></i><p>页面消息</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/widgets" class="nav-link"><i class="nav-icon fas fa-box"></i><p>前端组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/permission" class="nav-link"><i class="nav-icon fas fa-ban"></i><p>用户、角色、权限</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-authentication" class="nav-link"><i class="nav-icon fas fa-handshake"></i><p>自定义登录认证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-navbar" class="nav-link"><i class="nav-icon fas fa-compass"></i><p>自定义头部导航</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/qa" class="nav-link"><i class="nav-icon fas fa-question-circle"></i><p>常见问题</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/changelog" class="nav-link"><i class="nav-icon fas fa-history"></i><p>Changelog</p></a></li>
</ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper pl-5 pr-4 py-2" id="pjax-container">
        <div class="content-header">
            <h1 class="text-dark">基于数据模型的表单</h1>
        </div>

        <div class="content px-2">

            <div class="row">
                <div class="col">
                    <div class="toc m-4">
                        <ul>
                                                        <li>
                                <a href="#自定义工具">自定义工具</a>
                                                            </li>
                                                        <li>
                                <a href="#表单脚部">表单脚部</a>
                                                            </li>
                                                        <li>
                                <a href="#其它方法">其它方法</a>
                                                            </li>
                                                    </ul>
                    </div>
                </div>
                <div class="col">
                    <div id="ad" class="float-right">
                        <script async src="https://cdn.carbonads.com/carbon.js?serve=CK7DT53L&placement=laraveladminorg" id="_carbonads_js"></script>
                    </div>
                </div>
            </div>

            
<p><code>Encore\Admin\Form</code>类用于生成基于数据模型的表单，先来个例子，数据库中有<code>movies</code>表</p>
<pre><code class="language-sql">movies
    id          - integer
    title       - string
    director    - integer
    describe    - string
    rate        - tinyint
    released    - enum(0, 1)
    release_at  - timestamp
    created_at  - timestamp
    updated_at  - timestamp</code></pre>
<p>对应的数据模型为<code>App\Models\Movie</code>，下面的代码可以生成<code>movies</code>的数据表单：</p>
<pre><code class="language-php">
use App\Models\Movie;
use Encore\Admin\Form;

$form = new Form(new Movie);

// 显示记录id
$form-&gt;display('id', 'ID');

// 添加text类型的input框
$form-&gt;text('title', '电影标题');

$directors = [
    1 =&gt; 'John',
    2 =&gt; 'Smith',
    3 =&gt; 'Kate' ,
];

$form-&gt;select('director', '导演')-&gt;options($directors);

// 添加describe的textarea输入框
$form-&gt;textarea('describe', '简介');

// 数字输入框
$form-&gt;number('rate', '打分');

// 添加开关操作
$form-&gt;switch('released', '发布？');

// 添加日期时间选择框
$form-&gt;dateTime('release_at', '发布时间');

// 两个时间显示
$form-&gt;display('created_at', '创建时间');
$form-&gt;display('updated_at', '修改时间');
</code></pre>
<h2 id="自定义工具"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%B7%A5%E5%85%B7">自定义工具</a></h2>
<p>表单右上角默认有返回和跳转列表两个按钮工具, 可以使用下面的方式修改它:</p>
<pre><code class="language-php">$form-&gt;tools(function (Form\Tools $tools) {

    // 去掉`列表`按钮
    $tools-&gt;disableList();

    // 去掉`删除`按钮
    $tools-&gt;disableDelete();

    // 去掉`查看`按钮
    $tools-&gt;disableView();

    // 添加一个按钮, 参数可以是字符串, 或者实现了Renderable或Htmlable接口的对象实例
    $tools-&gt;add('&lt;a class="btn btn-sm btn-danger"&gt;&lt;i class="fa fa-trash"&gt;&lt;/i&gt;&amp;nbsp;&amp;nbsp;delete&lt;/a&gt;');
});</code></pre>
<h2 id="表单脚部"><a href="#%E8%A1%A8%E5%8D%95%E8%84%9A%E9%83%A8">表单脚部</a></h2>
<p>使用下面的方法去掉form脚部的元素</p>
<pre><code class="language-php">
$form-&gt;footer(function ($footer) {

    // 去掉`重置`按钮
    $footer-&gt;disableReset();

    // 去掉`提交`按钮
    $footer-&gt;disableSubmit();

    // 去掉`查看`checkbox
    $footer-&gt;disableViewCheck();

    // 去掉`继续编辑`checkbox
    $footer-&gt;disableEditingCheck();

    // 去掉`继续创建`checkbox
    $footer-&gt;disableCreatingCheck();

});
</code></pre>
<h2 id="其它方法"><a href="#%E5%85%B6%E5%AE%83%E6%96%B9%E6%B3%95">其它方法</a></h2>
<p>去掉提交按钮:</p>
<pre><code class="language-php">$form-&gt;disableSubmit();</code></pre>
<p>去掉重置按钮:</p>
<pre><code class="language-php">$form-&gt;disableReset();</code></pre>
<p>忽略掉不需要保存的字段</p>
<pre><code class="language-php">$form-&gt;ignore(['column1', 'column2', 'column3']);</code></pre>
<p>设置宽度</p>
<pre><code class="language-php">$form-&gt;setWidth(10, 2);</code></pre>
<p>设置表单提交的action</p>
<pre><code class="language-php">$form-&gt;setAction('admin/users');</code></pre>
<p>判断当前表单页是创建页面还是更新页面</p>
<blockquote>
<p>Since v1.7.6</p>
</blockquote>
<pre><code class="language-php">$form-&gt;isCreating();

$form-&gt;isEditing();</code></pre>
<blockquote>
<p>Since v1.8.0</p>
</blockquote>
<p>提交确认</p>
<pre><code class="language-php">$form-&gt;confirm('确定更新吗？', 'edit');

$form-&gt;confirm('确定创建吗？', 'create');

$form-&gt;confirm('确定提交吗？');</code></pre>
        </div>
    </div>
    <footer class="main-footer">
        <div class="float-right d-none d-sm-inline">
            v1.8
        </div>
        <strong>Documentation powered by <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    </footer>
</div>

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-52301626-3', 'auto');
    ga('send', 'pageview');

</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.js"></script>
<script type="text/javascript"> docsearch({
        apiKey: 'f67cec1a592c4a25a3e1d1c0dc38b6af',
        indexName: 'laravel-admin',
        inputSelector: '.docsearch',
        debug: false // Set debug to true if you want to inspect the dropdown
    });
</script>

<script src="/vendor/docs/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/vendor/docs/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="/vendor/docs/js/adminlte.min.js"></script>
<script src="/vendor/docs/plugins/jquery-pjax/jquery.pjax.js"></script>
<script src="/vendor/docs/plugins/prism/prism.js" data-manual></script>
<script src="/vendor/docs/js/docs.js?id=3" data-manual></script>
</body>
</html>
