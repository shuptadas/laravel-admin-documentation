<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Laravel admin | 基于数据模型的表格</title>


    <link rel="stylesheet" href="/css/google-fonts.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <link rel="stylesheet" href="/vendor/docs/plugins/prism/prism.css">
    <link rel="stylesheet" href="/vendor/docs/css/adminlte.min.css">
    <link rel="stylesheet" href="/vendor/docs/css/docs.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.css" />
    <script src="/vendor/docs/plugins/jquery/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed text-sm">
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
            </li>

                        <li class="nav-item dropdown">
                <a class="nav-link bg-info rounded dropdown-toggle" href="#" id="navbarVersionDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    1.x
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarVersionDropdown">
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/1.x">1.x</a>
                                        <a class="dropdown-item" href="https://laravel-admin.org/docs/zh/2.x">2.0-BETA</a>
                                    </div>
            </li>
                    </ul>

        <!-- SEARCH FORM -->
        <form class="form-check-inline ml-3">
            <div class="input-group input-group-sm">
                <input class="form-control form-control-navbar docsearch" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-navbar" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

        <span class="ml-5"><a href="/docs/zh/1.x/changelog#v1.8.9%20(2020-11-02)" class="text-danger">目前于1.8版本发现一处未授权访问安全漏洞，正在使用1.8版本的同学请尽快更新到v1.8.10版本！！！</a></span>

        <ul class="navbar-nav ml-auto">
            <li class="nav-item d-none d-sm-inline-block">
              <a href="/" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://demo.laravel-admin.org" target="_blank" class="nav-link">Demo</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="https://github.com/z-song/laravel-admin" class="nav-link" target="_blank"><i class="fab fa-github"></i></a>
            </li>

            <li class="nav-item dropdown ml-2">
                <a class="btn btn-info btn-sm" href="#" id="navbarLangDropdown" role="button"
                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-globe-asia"></i>
                </a>
                <div class="dropdown-menu py-0" aria-labelledby="navbarLangDropdown">
                                        <a class="dropdown-item" href="/docs/zh">中文</a>
                                        <a class="dropdown-item" href="/docs/en">English</a>
                                    </div>
            </li>
        </ul>
    </nav>

    <aside class="main-sidebar elevation-4 sidebar-light-info">
        <a href="/" class="brand-link logo-switch navbar-light text-info">
            <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Small" class="brand-image-xl logo-xs" style="height: 29px;margin-top: 1px;margin-left: 13px;">
            <span>
                <img src="https://laravel-admin.org/images/logo.png" alt="AdminLTE Docs Logo Large" class="brand-image-xs logo-xl" style="left: 30px">
                <span style="position: absolute;left:58px;" class="text-lg">aravel-admin</span>
            </span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <p></p><p></p><ul role="menu" class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview">
<li class="nav-item"><a href="/docs/zh/1.x/README" class="nav-link"><i class="nav-icon fas fa-home"></i><p>Overview</p></a></li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>入门
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/installation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>安装</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/quick-start" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快速开始</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/configuration" class="nav-link"><i class="nav-icon far fa-circle"></i><p>配置文件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/upgrading" class="nav-link"><i class="nav-icon far fa-circle"></i><p>版本升级</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>页面内容和布局</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/questions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>统一回复</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-th"></i><p>模型表格
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-grid" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-display" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列的显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-filters" class="nav-link"><i class="nav-icon far fa-circle"></i><p>查询过滤</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-column-filter" class="nav-link"><i class="nav-icon far fa-circle"></i><p>列过滤器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-inline-edit" class="nav-link"><i class="nav-icon far fa-circle"></i><p>行内编辑</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-actions" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义行&amp;批量操作</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-export" class="nav-link"><i class="nav-icon far fa-circle"></i><p>数据导出</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-header-footer" class="nav-link"><i class="nav-icon far fa-circle"></i><p>头部和脚部</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-total-row" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表格统计行</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-search" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷搜索</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-spec-selector" class="nav-link"><i class="nav-icon far fa-circle"></i><p>规格选择器</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-quick-create" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷创建</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-custom-tools" class="nav-link"><i class="nav-icon far fa-circle"></i><p>自定义工具</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-data" class="nav-link"><i class="nav-icon far fa-circle"></i><p>外部数据源</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-hotkeys" class="nav-link"><i class="nav-icon far fa-circle"></i><p>快捷键</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-grid-soft-deletes" class="nav-link"><i class="nav-icon far fa-circle"></i><p>软删除</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-paste"></i><p>模型表单
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-form" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基础组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-upload" class="nav-link"><i class="nav-icon far fa-circle"></i><p>图片/文件上传</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-json-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>JSON组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-relationships" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关系处理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-linkage" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单联动</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-field-management" class="nav-link"><i class="nav-icon far fa-circle"></i><p>组件管理</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-validation" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单验证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-callback" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单回调</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-init" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单初始化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-form-layout" class="nav-link"><i class="nav-icon far fa-circle"></i><p>表单布局</p></a></li>
</ul>
</li>
<li class="nav-item has-treeview">
<a href="#" class="nav-link"><i class="nav-icon fas fa-eye"></i><p>模型详情
<i class="right fas fa-angle-left"></i></p></a><ul class="nav nav-treeview" style="display: none;">
<li class="nav-item"><a href="/docs/zh/1.x/model-show" class="nav-link"><i class="nav-icon far fa-circle"></i><p>基本使用</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-fields" class="nav-link"><i class="nav-icon far fa-circle"></i><p>字段显示</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-relationship" class="nav-link"><i class="nav-icon far fa-circle"></i><p>关联关系</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/model-show-extension" class="nav-link"><i class="nav-icon far fa-circle"></i><p>显示扩展</p></a></li>
</ul>
</li>
<li class="nav-item"><a href="/docs/zh/1.x/model-tree" class="nav-link"><i class="nav-icon fas fa-tree"></i><p>数据模型树</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/data-form" class="nav-link"><i class="nav-icon fas fa-database"></i><p>数据表单</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/localization" class="nav-link"><i class="nav-icon fas fa-language"></i><p>语言本地化</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/frontend" class="nav-link"><i class="nav-icon fab fa-js"></i><p>CSS/JavaScript</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/extension-development" class="nav-link"><i class="nav-icon fas fa-anchor"></i><p>扩展开发</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/commands" class="nav-link"><i class="nav-icon fas fa-terminal"></i><p>控制台命令</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/content-message" class="nav-link"><i class="nav-icon fas fa-comments"></i><p>页面消息</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/widgets" class="nav-link"><i class="nav-icon fas fa-box"></i><p>前端组件</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/permission" class="nav-link"><i class="nav-icon fas fa-ban"></i><p>用户、角色、权限</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-authentication" class="nav-link"><i class="nav-icon fas fa-handshake"></i><p>自定义登录认证</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/custom-navbar" class="nav-link"><i class="nav-icon fas fa-compass"></i><p>自定义头部导航</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/qa" class="nav-link"><i class="nav-icon fas fa-question-circle"></i><p>常见问题</p></a></li>
<li class="nav-item"><a href="/docs/zh/1.x/changelog" class="nav-link"><i class="nav-icon fas fa-history"></i><p>Changelog</p></a></li>
</ul>
            </nav>
        </div>
    </aside>

    <div class="content-wrapper pl-5 pr-4 py-2" id="pjax-container">
        <div class="content-header">
            <h1 class="text-dark">基于数据模型的表格</h1>
        </div>

        <div class="content px-2">

            <div class="row">
                <div class="col">
                    <div class="toc m-4">
                        <ul>
                                                        <li>
                                <a href="#基础方法">基础方法</a>
                                                                <ul>
                                                                        <li>
                                        <a href="#添加列">添加列</a>
                                    </li>
                                                                        <li>
                                        <a href="#添加数据查询条件">添加数据查询条件</a>
                                    </li>
                                                                        <li>
                                        <a href="#设置每页显示行数">设置每页显示行数</a>
                                    </li>
                                                                        <li>
                                        <a href="#修改显示输出">修改显示输出</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用创建按钮">禁用创建按钮</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用分页条">禁用分页条</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用查询过滤器">禁用查询过滤器</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用导出数据按钮">禁用导出数据按钮</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用行选择checkbox">禁用行选择checkbox</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用行操作列">禁用行操作列</a>
                                    </li>
                                                                        <li>
                                        <a href="#禁用行选择器">禁用行选择器</a>
                                    </li>
                                                                        <li>
                                        <a href="#设置分页选择器选项">设置分页选择器选项</a>
                                    </li>
                                                                    </ul>
                                                            </li>
                                                        <li>
                                <a href="#关联模型">关联模型</a>
                                                                <ul>
                                                                        <li>
                                        <a href="#一对一">一对一</a>
                                    </li>
                                                                        <li>
                                        <a href="#一对多">一对多</a>
                                    </li>
                                                                        <li>
                                        <a href="#多对多">多对多</a>
                                    </li>
                                                                    </ul>
                                                            </li>
                                                    </ul>
                    </div>
                </div>
                <div class="col">
                    <div id="ad" class="float-right">
                        <script async src="https://cdn.carbonads.com/carbon.js?serve=CK7DT53L&placement=laraveladminorg" id="_carbonads_js"></script>
                    </div>
                </div>
            </div>

            
<p><code>Encore\Admin\Grid</code>类用于生成基于数据模型的表格，下面以<code>movies</code>表为例：</p>
<pre><code class="language-sql">movies
    id          - integer
    title       - string
    director    - integer
    describe    - string
    rate        - tinyint
    released    - enum(0, 1)
    release_at  - timestamp
    created_at  - timestamp
    updated_at  - timestamp</code></pre>
<p>对应的数据模型为<code>App\Models\Movie</code>，用下面的代码生成表<code>movies</code>的数据表格：</p>
<pre><code class="language-php">
use App\Models\Movie;
use Encore\Admin\Grid;

$grid = new Grid(new Movie);

// 第一列显示id字段，并将这一列设置为可排序列
$grid-&gt;column('id', 'ID')-&gt;sortable();

// 第二列显示title字段，由于title字段名和Grid对象的title方法冲突，所以用Grid的column()方法代替
$grid-&gt;column('title');

// 第三列显示director字段，通过display($callback)方法设置这一列的显示内容为users表中对应的用户名
$grid-&gt;column('director')-&gt;display(function($userId) {
    return User::find($userId)-&gt;name;
});

// 第四列显示为describe字段
$grid-&gt;column('describe');

// 第五列显示为rate字段
$grid-&gt;column('rate');

// 第六列显示released字段，通过display($callback)方法来格式化显示输出
$grid-&gt;column('released', '上映?')-&gt;display(function ($released) {
    return $released ? '是' : '否';
});

// 下面为三个时间字段的列显示
$grid-&gt;column('release_at');
$grid-&gt;column('created_at');
$grid-&gt;column('updated_at');

// filter($callback)方法用来设置表格的简单搜索框
$grid-&gt;filter(function ($filter) {

    // 设置created_at字段的范围查询
    $filter-&gt;between('created_at', 'Created Time')-&gt;datetime();
});
</code></pre>
<h2 id="基础方法"><a href="#%E5%9F%BA%E7%A1%80%E6%96%B9%E6%B3%95">基础方法</a></h2>
<p>模型表格有以下的一些基础方法</p>
<h3 id="添加列"><a href="#%E6%B7%BB%E5%8A%A0%E5%88%97">添加列</a></h3>
<pre><code class="language-php">
// 直接通过字段名`username`添加列
$grid-&gt;username('用户名');

// 效果和上面一样
$grid-&gt;column('username', '用户名');

// 显示JSON内嵌字段
$grid-&gt;column('profile-&gt;mobile', '手机号');

// 添加多列
$grid-&gt;columns('email', 'username' ...);</code></pre>
<h3 id="添加数据查询条件"><a href="#%E6%B7%BB%E5%8A%A0%E6%95%B0%E6%8D%AE%E6%9F%A5%E8%AF%A2%E6%9D%A1%E4%BB%B6">添加数据查询条件</a></h3>
<p>默认情况下，表格的数据没有任何查询条件，可以使用<code>model()</code>方法来给当前表格数据添加查询条件：</p>
<pre><code class="language-php">$grid-&gt;model()-&gt;where('id', '&gt;', 100);

$grid-&gt;model()-&gt;whereIn('id', [1, 2, 3]);

$grid-&gt;model()-&gt;whereBetween('votes', [1, 100]);

$grid-&gt;model()-&gt;whereColumn('updated_at', '&gt;', 'created_at');

$grid-&gt;model()-&gt;orderBy('id', 'desc');

$grid-&gt;model()-&gt;take(100);

...
</code></pre>
<p><code>$grid-&gt;model()</code>后面可以直接调用<code>Eloquent</code>的查询方法来给表格数据添加查询条件，更多查询方法参考<a href="https://laravel.com/docs/5.8/queries">文档</a>.</p>
<h3 id="设置每页显示行数"><a href="#%E8%AE%BE%E7%BD%AE%E6%AF%8F%E9%A1%B5%E6%98%BE%E7%A4%BA%E8%A1%8C%E6%95%B0">设置每页显示行数</a></h3>
<pre><code class="language-php">// 默认为每页20条
$grid-&gt;paginate(15);</code></pre>
<h3 id="修改显示输出"><a href="#%E4%BF%AE%E6%94%B9%E6%98%BE%E7%A4%BA%E8%BE%93%E5%87%BA">修改显示输出</a></h3>
<pre><code class="language-php">$grid-&gt;column('text')-&gt;display(function($text) {
    return str_limit($text, 30, '...');
});

$grid-&gt;column('name')-&gt;display(function ($name) {
    return "&lt;span class='label'&gt;$name&lt;/span&gt;";
});

$grid-&gt;column('email')-&gt;display(function ($email) {
    return "mailto:$email";
});

// 添加不存在的字段
$grid-&gt;column('column_not_in_table')-&gt;display(function () {
    return 'blablabla....';
});</code></pre>
<p><code>display()</code>方法接收的匿名函数绑定了当前行的数据对象，可以在里面调用当前行的其它字段数据</p>
<pre><code class="language-php">$grid-&gt;column('first_name');
$grid-&gt;column('last_name');

// 不存的字段列
$grid-&gt;column('full_name')-&gt;display(function () {
    return $this-&gt;first_name.' '.$this-&gt;last_name;
});</code></pre>
<h3 id="禁用创建按钮"><a href="#%E7%A6%81%E7%94%A8%E5%88%9B%E5%BB%BA%E6%8C%89%E9%92%AE">禁用创建按钮</a></h3>
<pre><code class="language-php">$grid-&gt;disableCreateButton();</code></pre>
<h3 id="禁用分页条"><a href="#%E7%A6%81%E7%94%A8%E5%88%86%E9%A1%B5%E6%9D%A1">禁用分页条</a></h3>
<pre><code class="language-php">$grid-&gt;disablePagination();</code></pre>
<h3 id="禁用查询过滤器"><a href="#%E7%A6%81%E7%94%A8%E6%9F%A5%E8%AF%A2%E8%BF%87%E6%BB%A4%E5%99%A8">禁用查询过滤器</a></h3>
<pre><code class="language-php">$grid-&gt;disableFilter();</code></pre>
<h3 id="禁用导出数据按钮"><a href="#%E7%A6%81%E7%94%A8%E5%AF%BC%E5%87%BA%E6%95%B0%E6%8D%AE%E6%8C%89%E9%92%AE">禁用导出数据按钮</a></h3>
<pre><code class="language-php">$grid-&gt;disableExport();</code></pre>
<h3 id="禁用行选择checkbox"><a href="#%E7%A6%81%E7%94%A8%E8%A1%8C%E9%80%89%E6%8B%A9checkbox">禁用行选择checkbox</a></h3>
<pre><code class="language-php">$grid-&gt;disableRowSelector();</code></pre>
<h3 id="禁用行操作列"><a href="#%E7%A6%81%E7%94%A8%E8%A1%8C%E6%93%8D%E4%BD%9C%E5%88%97">禁用行操作列</a></h3>
<pre><code class="language-php">$grid-&gt;disableActions();</code></pre>
<h3 id="禁用行选择器"><a href="#%E7%A6%81%E7%94%A8%E8%A1%8C%E9%80%89%E6%8B%A9%E5%99%A8">禁用行选择器</a></h3>
<pre><code class="language-php">$grid-&gt;disableColumnSelector();</code></pre>
<h3 id="设置分页选择器选项"><a href="#%E8%AE%BE%E7%BD%AE%E5%88%86%E9%A1%B5%E9%80%89%E6%8B%A9%E5%99%A8%E9%80%89%E9%A1%B9">设置分页选择器选项</a></h3>
<pre><code class="language-php">$grid-&gt;perPages([10, 20, 30, 40, 50]);</code></pre>
<h2 id="关联模型"><a href="#%E5%85%B3%E8%81%94%E6%A8%A1%E5%9E%8B">关联模型</a></h2>
<h3 id="一对一"><a href="#%E4%B8%80%E5%AF%B9%E4%B8%80">一对一</a></h3>
<p><code>users</code>表和<code>profiles</code>表通过<code>profiles.user_id</code>字段生成一对一关联</p>
<pre><code class="language-sql">uers
    id      - integer 
    name    - string
    email   - string

profiles
    id      - integer 
    user_id - integer 
    age     - string
    gender  - string</code></pre>
<p>对应的数据模分别为:</p>
<pre><code class="language-php">
class User extends Model
{
    public function profile()
    {
        return $this-&gt;hasOne(Profile::class);
    }
}

class Profile extends Model
{
    public function user()
    {
        return $this-&gt;belongsTo(User::class);
    }
}
</code></pre>
<p>通过下面的代码可以关联在一个grid里面:</p>
<pre><code class="language-php">
$grid = new Grid(new User);

$grid-&gt;column('id', 'ID')-&gt;sortable();

$grid-&gt;column('name');
$grid-&gt;column('email');

$grid-&gt;column('profile.age');
$grid-&gt;column('profile.gender');

//or
$grid-&gt;profile()-&gt;age();
$grid-&gt;profile()-&gt;gender();
</code></pre>
<h3 id="一对多"><a href="#%E4%B8%80%E5%AF%B9%E5%A4%9A">一对多</a></h3>
<p><code>posts</code>表和<code>comments</code>表通过<code>comments.post_id</code>字段生成一对多关联</p>
<pre><code class="language-sql">posts
    id      - integer 
    title   - string
    content - text

comments
    id      - integer 
    post_id - integer 
    content - string</code></pre>
<p>对应的数据模分别为:</p>
<pre><code class="language-php">
class Post extends Model
{
    public function comments()
    {
        return $this-&gt;hasMany(Comment::class);
    }
}

class Comment extends Model
{
    public function post()
    {
        return $this-&gt;belongsTo(Post::class);
    }
}
</code></pre>
<p>通过下面的代码可以让两个模型在grid里面互相关联:</p>
<pre><code class="language-php">
$grid = new Grid(new Post);

$grid-&gt;column('id', 'id')-&gt;sortable();
$grid-&gt;column('title');
$grid-&gt;column('content');

$grid-&gt;column('comments', '评论数')-&gt;display(function ($comments) {
    $count = count($comments);
    return "&lt;span class='label label-warning'&gt;{$count}&lt;/span&gt;";
});

return $grid;
</code></pre>
<pre><code class="language-php">
$grid = new Grid(new Comment);
$grid-&gt;column('id');
$grid-&gt;column('post.title');
$grid-&gt;column('content');

return $grid;</code></pre>
<h3 id="多对多"><a href="#%E5%A4%9A%E5%AF%B9%E5%A4%9A">多对多</a></h3>
<p><code>users</code>和<code>roles</code>表通过中间表<code>role_users</code>产生多对多关系</p>
<pre><code class="language-sql">users
    id       - integer 
    username - string
    password - string
    name     - string 

roles
    id      - integer 
    name    - string
    slug    - string

role_users
    role_id - integer 
    user_id - integer </code></pre>
<p>对应的数据模分别为:</p>
<pre><code class="language-php">
class User extends Model
{
    public function roles()
    {
        return $this-&gt;belongsToMany(Role::class);
    }
}

class Role extends Model
{
    public function users()
    {
        return $this-&gt;belongsToMany(User::class);
    }
}
</code></pre>
<p>通过下面的代码可以让两个模型在grid里面互相关联:</p>
<pre><code class="language-php">
$grid = new Grid(new User);

$grid-&gt;column('id', 'ID')-&gt;sortable();
$grid-&gt;column('username');
$grid-&gt;column('name');

$grid-&gt;column('roles')-&gt;display(function ($roles) {

    $roles = array_map(function ($role) {
        return "&lt;span class='label label-success'&gt;{$role['name']}&lt;/span&gt;";
    }, $roles);

    return join('&amp;nbsp;', $roles);
});
</code></pre>
        </div>
    </div>
    <footer class="main-footer">
        <div class="float-right d-none d-sm-inline">
            v1.8
        </div>
        <strong>Documentation powered by <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
    </footer>
</div>

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-52301626-3', 'auto');
    ga('send', 'pageview');

</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/docsearch.js@2/dist/cdn/docsearch.min.js"></script>
<script type="text/javascript"> docsearch({
        apiKey: 'f67cec1a592c4a25a3e1d1c0dc38b6af',
        indexName: 'laravel-admin',
        inputSelector: '.docsearch',
        debug: false // Set debug to true if you want to inspect the dropdown
    });
</script>

<script src="/vendor/docs/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/vendor/docs/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="/vendor/docs/js/adminlte.min.js"></script>
<script src="/vendor/docs/plugins/jquery-pjax/jquery.pjax.js"></script>
<script src="/vendor/docs/plugins/prism/prism.js" data-manual></script>
<script src="/vendor/docs/js/docs.js?id=3" data-manual></script>
</body>
</html>
